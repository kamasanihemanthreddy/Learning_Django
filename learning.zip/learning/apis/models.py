from django.db import models

# Create your models here.

class University(models.Model):
	name = models.CharField(max_length=50)

	class Meta:
		verbose_name = 	"University"
		verbose_name_plural = "Universities"

	def __str__(self):
		return self.name


class Student(models.Model):
	firstname = models.CharField(max_length=50)
	lastname = models.CharField(max_length=30)
	University = models.ForeignKey(University, on_delete=models.CASCADE)


	class Meta:
		verbose_name = 'Student'
		verbose_name_plural="Students"

	def __str__(self):
		return '%s %s' %(self.firstname , self.lastname)