from django.contrib import admin
from django.urls import path, include

from django.conf.urls import url
from rest_framework import routers
from apis.views import StudentViewSet, UniversityViewSet


from . import views

router = routers.DefaultRouter()
router.register(r'students', StudentViewSet)
router.register(r'universities', UniversityViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
