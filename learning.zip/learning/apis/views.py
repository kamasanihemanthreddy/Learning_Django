from django.shortcuts import render
from rest_framework import viewsets
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import University, Student
from .serializers import UniversitySerializer, StudentSerializer
import requests
# Create your views here.

class StudentViewSet(LoginRequiredMixin,viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer


class UniversityViewSet(LoginRequiredMixin,viewsets.ModelViewSet):
    queryset = University.objects.all()
    serializer_class = UniversitySerializer




def home(request):
	response = requests.get('http://api.ipstack.com/157.48.201.245?access_key=add104e21a57686fb07eda68f399fa94')
	geodata = response.json()
	context = {'ip':geodata['ip'],'country':geodata['city']}
	return render(request, 'index.html',context)