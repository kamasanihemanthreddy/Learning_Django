from django.apps import AppConfig


class LearningDjangoConfig(AppConfig):
    name = 'learning_django'
