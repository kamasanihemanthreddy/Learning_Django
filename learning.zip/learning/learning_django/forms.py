from django import forms
from django.contrib.auth.models import User
from bootstrap3_datetime.widgets import DateTimePicker
from django.core.exceptions import ValidationError
from django.forms.models import inlineformset_factory, modelform_factory
from .models import (
			Topic,
			Entry,
			NewCompany,
			Sheed,
			SheedLoading,
			BirthdayModel,

)

SHEED_NUMBER=[(x, x) for x in range(1, 50)]

class TopicForm(forms.ModelForm):
	text = forms.CharField(widget=forms.TextInput(
		attrs={
			'class':'form-control',
			'placeholder':'topic',
			}
		))
	inputdate = forms.DateTimeField(widget=forms.TextInput(
	 	attrs={
	 		'class':'form-control',
	 		'id':'datetimepicker',
	 		}
	 	))


	class Meta:
		model = Topic
		fields = ['text']

class EntryForm(forms.ModelForm):
	class Meta:
		model = Entry
		fields = ['text']
		labels = {'text':'Name*'}
		widgets = {'text':forms.Textarea(attrs={
			'cols':8,
			'class':'form-control'
				}
			)}




class NewCompanyForm(forms.ModelForm):
		name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Company Name',}))
		email = forms.EmailField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Email_Id',}))
		phone = forms.IntegerField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Phone Number',}))
		website = forms.URLField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Website',}))
		ownername = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Owner Name',}))
		totalsheeds = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Total Sheeds Under Company',}))
		doorno = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Door No',}))
		street = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Street',}))
		landmark = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'LandMark',}))
		district = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'District',}))
		state = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'State ',}))
		pincode = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Pin Code',}))

		def clean_email(self):
			email = self.cleaned_data['email']
			if NewCompany.objects.filter(email=email).exists():
				raise ValidationError("Email already exists")
			return email

		def clean_phone(self):
			phone = self.cleaned_data['phone']
			if NewCompany.objects.filter(phone=phone).exists():
				raise ValidationError("Phone Number already exists")
			return phone


		class Meta:
			model = NewCompany
			exclude = ['date_created']

class SheedForm(forms.ModelForm):
	companyname	= forms.ModelChoiceField(queryset=NewCompany.objects.all().order_by('name'),widget=forms.Select(attrs={'class':'form-control'}),required=True)
	username = forms.ModelChoiceField(queryset=User.objects.all().order_by('-username'), widget=forms.Select(attrs={'class':'form-control'}))
	date = forms.DateTimeField(widget=forms.TextInput(
	 	attrs={
	 		'class':'form-control',
	 		'id':'datetimepicker',
	 		}
	 	))
	vehicle_no = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Vehicle No',}), required=True)
	drivername = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Driver Name',}), required=True)
	driverno = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Driver Phone Number',}), required=True)
	driveraddress = forms.CharField(
					widget=forms.Textarea(
						attrs={
							'cols':5,
							'rows':2,
							'class':'form-control',
							'placeholder':'Address Of Delivery',
						}),
					required=True,
					)
	sheednumber = forms.ChoiceField(choices=SHEED_NUMBER ,widget=forms.Select(attrs={'class':'form-control','placeholder':'Sheed Number',}), required=True)
	class Meta:
		model = Sheed
		fields = '__all__'

class SheedLoadingForm(forms.ModelForm):

	class Meta:
		model = SheedLoading
		exclude = ['date_of_loading']
		widgets= {
				'empty_weight':forms.TextInput(
					attrs={
						'class':'form-control',
						'placeholder':'Empty Weight',
					}),
				'load_weight':forms.TextInput(
					attrs={
						'class':'form-control',
						'placeholder':'Load Weight',
					})
		}


class BirthdayForm(forms.ModelForm):


	class Meta:
		model = BirthdayModel
		fields='__all__'