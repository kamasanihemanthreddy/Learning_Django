from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Topic(models.Model):

	text = models.CharField(max_length=200)
	date_add = models.DateTimeField(auto_now_add=True)
	inputdate = models.DateTimeField(blank=False, null=False)

	def __str__(self):
		 return self.text

class Entry(models.Model):
	topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
	text = models.TextField()
	date_added = models.DateTimeField(auto_now_add=True)

	class Meta:
		verbose_name_plural = 'entries'

	def __str__(self):
		return self.text[:50] + "......."


class NewCompany(models.Model):

	name = models.CharField(max_length=200)
	email = models.EmailField(max_length=100)
	phone = models.BigIntegerField()
	website = models.URLField(max_length=100,null=True)
	ownername = models.CharField(max_length=100)
	date_created = models.DateTimeField(auto_now_add=True)
	totalsheeds = models.IntegerField()
	doorno = models.CharField(max_length=10, blank=True)
	street = models.CharField(max_length=50,blank=True)
	landmark = models.CharField(max_length=50,blank=True)
	district = models.CharField(max_length=50, blank=True)
	state = models.CharField(max_length=50,blank=True)
	pincode = models.IntegerField(blank=True, null=True)

	def __str__(self):
		return self.name



class Sheed(models.Model):
	companyname = models.ForeignKey(NewCompany, on_delete=models.CASCADE)
	username = models.ForeignKey(User, on_delete=models.CASCADE)
	date = models.DateTimeField()
	vehicle_no =models.CharField(max_length=15)
	drivername = models.CharField(max_length=25)
	driverno =models.BigIntegerField()
	driveraddress = models.CharField(max_length=30)
	sheednumber = models.IntegerField(null=True)
	def __str__(self):
		return "%s" % (self.companyname)

class SheedLoading(models.Model):
	companyname = models.ForeignKey(Sheed, on_delete=models.CASCADE, default=Sheed)
	empty_weight = models.FloatField(null=False)
	load_weight  = models.FloatField(null=False)
	date_of_loading = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return '%s' %(self.id)



class BirthdayModel(models.Model):
	name = models.CharField(max_length=25)
	event = models.CharField(max_length=150)
	phone = models.CharField(max_length=15, null=True)
	dob = models.DateField()
	date =  models.DateTimeField(auto_now_add=True)
	uid = models.BigIntegerField()


	def __str__(self):
		return self.name