from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.template.response import TemplateResponse
from django.views.generic import View
from django.contrib.auth.models import User
from django.contrib import messages
from django.urls import reverse
from django.db.models.functions import Concat
from django.db.models import Value
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import get_template
from .utils import render_to_pdf, str_to_num, birthday_sms
#icalender 
import datetime
from icalendar import Calendar, Event 
from .models import BirthdayModel
from .forms import BirthdayForm
from datetime import date
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
@login_required
def birthdayview(request):
	file_open = open('files.ics','rb')
	data = Calendar.from_ical(file_open.read())

	for a in data.walk():
		if a.name == 'VEVENT':
			names = a.get('summary')
			event = a.get('summary')
			dobs=a.decoded('DTSTART')
			uids = a.get('uid')
			uidint = str_to_num(uids)
			ins = BirthdayForm().save(commit=False)
			ins.name = names[:15]
			ins.dob = dobs
			ins.event = event
			ins.uid = uidint
			ins.save()
			print("loop  it...........")



@login_required
def birthdaylist(request):
	today = date.today()
	start = datetime.date.today()
	end = start + datetime.timedelta(days=0)
	birthday_list =BirthdayModel.objects.all()
	message_list = BirthdayModel.objects.filter(dob__range=(start,end))
	for a in message_list:
		if a.dob and a.phone:
			message = "Happy Birthday!!!!! Hope your special day brings you all that your heart desires! \n ---Hemanth Reddy "
			phonenumber = a.phone
			if phonenumber<=9:
				print("invalid Number")
			
			result = birthday_sms(message,phonenumber)
			if result:
				print("success")
			else:
				print("not success ")		

	search = request.GET.get('q')
	if search:
		birthday_list = birthday_list.filter(
			Q(name__icontains=search)|
			Q(event__icontains=search)|
			Q(phone__icontains=search)
			).distinct()
	
	paginator = Paginator(birthday_list, 10)
	page = request.GET.get('page', 1)
	try:
		birthday = paginator.page(page)
	except PageNotAnInteger:
		birthday = paginator.page(1)
	except EmptyPage:
		birthday = paginator.page(paginator.num_pages)
	content = {'birthday':birthday}
	return render(request, 'learn_django/birthday.html', content)


@login_required
def edit_birthday(request, bd_id):
	birthday_id = BirthdayModel.objects.get(id=bd_id)
	if request.method != 'POST':
		form = BirthdayForm(instance=birthday_id)
	else:
		form = BirthdayForm(instance=birthday_id, data=request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, "Data Updated Successfully")
			return redirect('learning_django:birthday')
		else:
			print(form.errors)
	content = {'form':form, 'birthday':birthday_id}
	return render(request, 'learn_django/birthday_edit.html', content)
		

