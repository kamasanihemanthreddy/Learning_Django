from django.contrib import admin

# Register your models here.
from learning_django.models import (
            Topic,
            Entry,
            NewCompany,
            Sheed,
            SheedLoading
)

admin.site.register(Topic)
admin.site.register(Entry)
admin.site.register(NewCompany)
admin.site.register(Sheed)
admin.site.register(SheedLoading)

