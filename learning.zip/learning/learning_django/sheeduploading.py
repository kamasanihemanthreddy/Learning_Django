from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.template.response import TemplateResponse
from django.views.generic import View
from django.contrib.auth.models import User
from django.contrib import messages
from django.urls import reverse
from django.db.models.functions import Concat
from django.db.models import Value
from django.utils import timezone

@login_required
def list_company_loading(request, load_id=None):
    if load_id:
        company_id = SheedLoading.objects.get(id=load_id)
        load_data = company_id.entry_set.order_by('date_of_loading')
        context = {'company_id':company_id, 'load_data':load_data}
        return render(request, 'learn_django/bird_loading_form.html', context)
    else:
        company_loading_list = Sheed.objects.order_by('date')
        content = {'company_loading_list':company_loading_list}
        return render(request, 'learn_django/loading_form.html', content)
