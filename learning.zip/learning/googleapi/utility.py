from datetime import datetime

def nanoseconds(nanotime):
    dt = datetime.fromtimestamp(nanotime).isoformat()
    return dt
