from django.shortcuts import render

# Create your views here.
import os
import logging
import httplib2
import requests

from googleapiclient.discovery import build
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseBadRequest
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import CredentialsModel
from learning import settings
from oauth2client.contrib import xsrfutil
from oauth2client.client import flow_from_clientsecrets, OAuth2WebServerFlow
from oauth2client.contrib.django_util.storage import DjangoORMStorage

# CLIENT_SECRETS, name of a file containing the OAuth 2.0 information for this
# application, including client_id and client_secret, which are found
# on the API Access tab on the Google APIs
# Console <http://code.google.com/apis/console>

FLOW = flow_from_clientsecrets(
    settings.GOOGLE_OAUTH2_CLIENT_SECRETS_JSON,
    scope='https://www.googleapis.com/auth/contacts',
    redirect_uri='http://127.0.0.1:8000/home/google/oauth2callback')

uri = 'http://127.0.0.1:8000/home/google/oauth2callback'
logging.getLogger('googleapicliet.discovery_cache').setLevel(logging.ERROR)
def home(request):
  storage = DjangoORMStorage(CredentialsModel, 'id', request.user, 'credential')
  credential = storage.get()
  if credential is None or credential.invalid == True:
    FLOW.params['state'] = xsrfutil.generate_token(settings.SECRET_KEY,
                                                   request.user)
    authorize_url = FLOW.step1_get_authorize_url()
    return HttpResponseRedirect(authorize_url)
  else:
    http = httplib2.Http()
    http = credential.authorize(http)
    service = build("people", "v1", http=http)
    results = service.people().connections().list(
        resourceName = 'people/me',
        personFields = 'names,phoneNumbers',
      ).execute()
    connections = results.get('connections', [])
    print(connections)
     

    return render(request, 'welcome.html', {'connections':connections})


@login_required
def auth_return(request):
  token_var = xsrfutil.validate_token(settings.SECRET_KEY, bytearray(request.GET['state'], 'utf8'), request.user) 
  if not token_var:
    return  HttpResponseBadRequest()
  credential = FLOW.step2_exchange(request.GET)
  storage = DjangoORMStorage(CredentialsModel, 'id', request.user, 'credential')
  storage.put(credential)
  return HttpResponseRedirect("/home/")

 