from django.apps import AppConfig


class GoogleapiConfig(AppConfig):
    name = 'googleapi'
