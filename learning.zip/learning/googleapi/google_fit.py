from django.shortcuts import render

# Create your views here.
import os
import logging
import httplib2
import requests
from .utility import nanoseconds

from googleapiclient.discovery import build
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseBadRequest
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import CredentialsModel, GoogleFitModel
from learning import settings
from oauth2client.contrib import xsrfutil
from oauth2client.client import flow_from_clientsecrets, OAuth2WebServerFlow
from oauth2client.contrib.django_util.storage import DjangoORMStorage

# CLIENT_SECRETS, name of a file containing the OAuth 2.0 information for this
# application, including client_id and client_secret, which are found
# on the API Access tab on the Google APIs
# Console <http://code.google.com/apis/console>
CLIENT_AUTH = settings.GOOGLE_OAUTH2_CLIENT_SECRETS_JSON
CLIENT_ID ='159115056006-d895babvameaafdpvvh49o00v1b612tb.apps.googleusercontent.com'
CLIENT_SECRET ='aNGgf9WAW1TnS5XQVQFmuHal'
OAUTH_SCOPE = 'https://www.googleapis.com/auth/fitness.activity.read'
DATA_SOURCE = 'derived:com.google.step_count.delta:com.google.android.gms:estimated_steps'
DATA_SET = "1536566381-1536652781"
REDIRECT_URL = 'http://127.0.0.1:8000/home/google/gfit/oauth2callback'
FLOW = OAuth2WebServerFlow(CLIENT_ID,CLIENT_SECRET,OAUTH_SCOPE,redirect_uri="http://127.0.0.1:8000/home/google/gfit/oauth2callback")

uri = 'http://127.0.0.1:8000/home/google/gfit/oauth2callback'
logging.getLogger('googleapicliet.discovery_cache').setLevel(logging.ERROR)
def gfit(request):
  storage = DjangoORMStorage(GoogleFitModel, 'id', request.user, 'credential')
  credential = storage.get()
  if credential is None or credential.invalid == True:
    FLOW.params['state'] = xsrfutil.generate_token(settings.SECRET_KEY,
                                                   request.user)
    authorize_url = FLOW.step1_get_authorize_url()
    return HttpResponseRedirect(authorize_url)
  else:
    http = httplib2.Http()
    http = credential.authorize(http)
    service = build("fitness", "v1", http=http)
    g_data = service.users().dataSources().datasets().get(userId='me', dataSourceId=DATA_SOURCE, datasetId=DATA_SET).execute()
    data_point =g_data["point"]
    print(data_point)
    return render(request, 'welcome.html',)


@login_required
def g_auth(request):
  token_var = xsrfutil.validate_token(settings.SECRET_KEY, bytearray(request.GET['state'], 'utf8'), request.user)
  if not token_var:
    return  HttpResponseBadRequest()
  credential = FLOW.step2_exchange(request.GET)
  storage = DjangoORMStorage(GoogleFitModel, 'id', request.user, 'credential')
  storage.put(credential)
  return HttpResponseRedirect("/home/")
