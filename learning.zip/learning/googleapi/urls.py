from django.contrib import admin
from django.urls import path, include
from . import views
from . import google_fit

urlpatterns = [
	path('g-people/', views.home ,name="home"),
	path('gfit/', google_fit.gfit, name='gfit'),
	path('gfit/oauth2callback',google_fit.g_auth, name='g_oauth2callback'),
	path('oauth2callback/', views.auth_return, name="oauth2callback"),
]
